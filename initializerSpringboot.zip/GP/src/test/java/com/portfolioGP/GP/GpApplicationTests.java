package com.portfolioGP.GP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpApplicationTests {

	@Test
	void contextLoads() {
	}

}
